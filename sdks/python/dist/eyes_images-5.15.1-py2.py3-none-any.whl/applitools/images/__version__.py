from __future__ import absolute_import

from ..selenium.__version__ import __version__  # noqa
